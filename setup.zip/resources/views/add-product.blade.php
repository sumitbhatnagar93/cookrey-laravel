@extends('layouts.app')
@section('content')

  <div id="app">
      <add-product></add-product>
  </div>
@endsection

